# Java EE 7 - GlassFish WebSockets Chat Tutorial

An example setting up a websocket-enabled chat system using Java EE 7, custom encoders/decoders, GlassFish 4, the new Java API for JSON Processing and Bootstrap.

For more detailed information, please feel free to have a look at my blog at [www.hascode.com].

----

**2013 Micha Kops / hasCode.com**

   [www.hascode.com]:http://www.hascode.com/
